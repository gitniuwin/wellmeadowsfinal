<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Wellmeadows — Patient Details</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --navy:#1B2D5B; --navy-dark:#111e3f; --navy-light:#2a4080;
    --sky:#5B9BD5; --sky-light:#A8CBF0; --sky-pale:#D6EAFA;
    --white:#FFFFFF; --off-white:#F4F8FC; --muted:#6B7E9F;
    --border:#C8D9EE; --text:#1a2640; --sidebar-w:210px;
    --error:#D94F4F; --success:#2E8B6A; --warn:#C88000;
  }
  body { font-family:'DM Sans',sans-serif; background:var(--off-white); color:var(--text); display:flex; min-height:100vh; }
  .sidebar { width:var(--sidebar-w); background:var(--navy); display:flex; flex-direction:column; position:fixed; top:0; left:0; bottom:0; z-index:100; }
  .sidebar-logo { padding:22px 20px 18px; border-bottom:1px solid rgba(255,255,255,0.08); display:flex; align-items:center; gap:10px; }
  .logo-icon-sm { width:34px; height:34px; background:var(--sky); border-radius:8px; display:flex; align-items:center; justify-content:center; }
  .logo-icon-sm svg { width:18px; height:18px; fill:white; }
  .logo-text { font-family:'Playfair Display',serif; font-size:13px; color:white; line-height:1.2; }
  .logo-text span { display:block; font-family:'DM Sans',sans-serif; font-size:9px; color:var(--sky-light); letter-spacing:1px; text-transform:uppercase; }
  .nav-section { padding:16px 12px 8px; font-size:9px; letter-spacing:1.5px; text-transform:uppercase; color:rgba(255,255,255,0.3); font-weight:500; }
  .nav-item { display:flex; align-items:center; gap:10px; padding:10px 16px; margin:1px 8px; border-radius:8px; color:rgba(255,255,255,0.55); font-size:13px; transition:all 0.15s; text-decoration:none; }
  .nav-item:hover { background:rgba(255,255,255,0.08); color:white; }
  .nav-item.active { background:rgba(91,155,213,0.25); color:white; font-weight:500; }
  .nav-item svg { width:16px; height:16px; flex-shrink:0; }
  .sidebar-footer { margin-top:auto; padding:16px 12px; border-top:1px solid rgba(255,255,255,0.08); }
  .user-card { display:flex; align-items:center; gap:10px; padding:10px 12px; }
  .avatar { width:32px; height:32px; border-radius:50%; background:var(--sky); display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:600; color:white; }
  .user-name { font-size:12px; font-weight:500; color:white; }
  .user-role { font-size:10px; color:var(--sky-light); }
  .sign-out-btn { width:100%; margin-top:6px; padding:8px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); border-radius:7px; color:rgba(255,255,255,0.5); font-family:'DM Sans',sans-serif; font-size:12px; cursor:pointer; }
  .sign-out-btn:hover { background:rgba(255,255,255,0.12); color:white; }

  .main { margin-left:var(--sidebar-w); flex:1; display:flex; flex-direction:column; }
  .topbar { background:white; border-bottom:1px solid var(--border); padding:0 28px; height:58px; display:flex; align-items:center; justify-content:space-between; }
  .topbar h2 { font-family:'Playfair Display',serif; font-size:20px; }
  .topbar-right { display:flex; gap:10px; }
  .back-btn { display:flex; align-items:center; gap:6px; padding:8px 16px; border:1px solid var(--border); border-radius:8px; font-size:13px; color:var(--muted); text-decoration:none; }
  .back-btn:hover { background:var(--sky-pale); }
  .edit-btn { padding:8px 16px; background:var(--navy); color:white; border-radius:8px; font-size:13px; text-decoration:none; }
  .edit-btn:hover { background:var(--navy-light); }

  .content { padding:28px; max-width:800px; }

  /* Profile header */
  .profile-header { background:white; border:1px solid var(--border); border-radius:12px; padding:24px; display:flex; align-items:center; gap:20px; margin-bottom:20px; }
  .profile-avatar { width:64px; height:64px; border-radius:50%; background:var(--sky-pale); border:2px solid var(--sky-light); display:flex; align-items:center; justify-content:center; font-family:'Playfair Display',serif; font-size:24px; color:var(--navy); flex-shrink:0; }
  .profile-name { font-family:'Playfair Display',serif; font-size:22px; color:var(--navy-dark); }
  .profile-num { font-size:13px; color:var(--muted); margin-top:2px; }
  .profile-badges { display:flex; gap:8px; margin-top:8px; }
  .badge { display:inline-flex; align-items:center; padding:3px 10px; border-radius:20px; font-size:11px; font-weight:500; }
  .badge-admitted { background:#DFFBEF; color:#1a7a50; }
  .badge-outpatient { background:#FFF4E0; color:#a06000; }
  .badge-male { background:#EBF3FF; color:#1a4a8a; }
  .badge-female { background:#FDE8F5; color:#8a1a5a; }
  .badge-other { background:#F0F0F0; color:#555; }

  /* Info grid */
  .info-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px; }
  .info-card { background:white; border:1px solid var(--border); border-radius:12px; padding:20px; }
  .info-card-title { font-size:11px; text-transform:uppercase; letter-spacing:1px; color:var(--muted); font-weight:500; margin-bottom:14px; }
  .info-row { display:flex; flex-direction:column; margin-bottom:12px; }
  .info-row:last-child { margin-bottom:0; }
  .info-label { font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:0.5px; }
  .info-value { font-size:14px; color:var(--text); font-weight:500; margin-top:2px; }

  /* Ward/Bed card */
  .ward-card { background:var(--sky-pale); border:1px solid var(--sky-light); border-radius:12px; padding:20px; margin-bottom:20px; }
  .ward-card-title { font-size:12px; text-transform:uppercase; letter-spacing:1px; color:var(--navy); font-weight:600; margin-bottom:10px; }
  .ward-detail { font-size:14px; color:var(--navy-dark); }
  .no-ward { font-size:13px; color:var(--muted); font-style:italic; }

  /* History links */
  .links-card { background:white; border:1px solid var(--border); border-radius:12px; padding:20px; }
  .links-title { font-size:12px; text-transform:uppercase; letter-spacing:1px; color:var(--muted); font-weight:500; margin-bottom:14px; }
  .link-row { display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid var(--border); }
  .link-row:last-child { border-bottom:none; }
  .link-label { font-size:13px; color:var(--text); }
  .link-action { font-size:12px; color:var(--sky); text-decoration:none; font-weight:500; }
  .link-action:hover { text-decoration:underline; }
</style>
</head>
<body>
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon-sm"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg></div>
    <div class="logo-text">Wellmeadows<span>Hospital</span></div>
  </div>
  <div class="nav-section">Main Menu</div>
  <a class="nav-item active" href="{{ route('patients.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
    Patients
  </a>
  <a class="nav-item" href="{{ route('staff.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
    Staff & Depts
  </a>
  <a class="nav-item" href="{{ route('wards.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
    Wards
  </a>
  <a class="nav-item" href="{{ route('appointments.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
    Appointments
  </a>
  <a class="nav-item" href="{{ route('billing.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
    Billing
  </a>
  <div class="sidebar-footer">
    <div class="user-card">
      <div class="avatar">{{ strtoupper(substr(auth()->user()->first_name, 0, 1)) }}</div>
      <div>
        <div class="user-name">{{ auth()->user()->first_name }}</div>
        <div class="user-role">{{ auth()->user()->role }}</div>
      </div>
    </div>
    <form method="POST" action="{{ route('logout') }}">
      @csrf
      <button type="submit" class="sign-out-btn">Sign out</button>
    </form>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <h2>Patient Details</h2>
    <div class="topbar-right">
      <a href="{{ route('patients.index') }}" class="back-btn">← Back</a>
      <a href="{{ route('patients.edit', $patient) }}" class="edit-btn">Edit Patient</a>
    </div>
  </div>

  <div class="content">

    <!-- Profile Header -->
    <div class="profile-header">
      <div class="profile-avatar">{{ strtoupper(substr($patient->first_name, 0, 1)) }}</div>
      <div>
        <div class="profile-name">{{ $patient->full_name }}</div>
        <div class="profile-num">{{ $patient->patient_number }}</div>
        <div class="profile-badges">
          <span class="badge {{ $patient->is_admitted ? 'badge-admitted' : 'badge-outpatient' }}">
            {{ $patient->is_admitted ? 'Admitted' : 'Outpatient' }}
          </span>
          <span class="badge {{ $patient->gender === 'Male' ? 'badge-male' : ($patient->gender === 'Female' ? 'badge-female' : 'badge-other') }}">
            {{ $patient->gender }}
          </span>
        </div>
      </div>
    </div>

    <!-- Info -->
    <div class="info-grid">
      <div class="info-card">
        <div class="info-card-title">Personal Information</div>
        <div class="info-row">
          <span class="info-label">Full Name</span>
          <span class="info-value">{{ $patient->full_name }}</span>
        </div>
        <div class="info-row">
          <span class="info-label">Date of Birth</span>
          <span class="info-value">{{ $patient->date_of_birth->format('d M Y') }} (Age {{ $patient->date_of_birth->age }})</span>
        </div>
        <div class="info-row">
          <span class="info-label">Gender</span>
          <span class="info-value">{{ $patient->gender }}</span>
        </div>
      </div>
      <div class="info-card">
        <div class="info-card-title">Contact Information</div>
        <div class="info-row">
          <span class="info-label">Contact Number</span>
          <span class="info-value">{{ $patient->contact_number ?? '—' }}</span>
        </div>
        <div class="info-row">
          <span class="info-label">Address</span>
          <span class="info-value">{{ $patient->address ?? '—' }}</span>
        </div>
        <div class="info-row">
          <span class="info-label">Registered On</span>
          <span class="info-value">{{ $patient->created_at->format('d M Y') }}</span>
        </div>
      </div>
    </div>

    <!-- Ward / Bed -->
    @if($patient->is_admitted)
    <div class="ward-card">
      <div class="ward-card-title">Ward & Bed Assignment</div>
      @if($patient->bed)
        <div class="ward-detail">
          Bed <strong>{{ $patient->bed->bed_number }}</strong>
          — Ward: <strong>{{ $patient->bed->ward->name ?? 'N/A' }}</strong>
        </div>
      @else
        <div class="no-ward">Patient is admitted but not yet assigned to a bed. Go to <a href="{{ route('wards.index') }}">Wards</a> to assign one.</div>
      @endif
    </div>
    @endif

    <!-- Quick links to M4 -->
    <div class="links-card">
      <div class="links-title">Patient Records</div>
      <div class="link-row">
        <span class="link-label">Appointments</span>
        <a href="{{ route('appointments.index') }}" class="link-action">View all →</a>
      </div>
      <div class="link-row">
        <span class="link-label">Treatments & Diagnoses</span>
        <a href="{{ route('treatments.index') }}" class="link-action">View all →</a>
      </div>
      <div class="link-row">
        <span class="link-label">Treatment History</span>
        <a href="{{ route('history.index', ['patient_id' => $patient->id]) }}" class="link-action">View history →</a>
      </div>
    </div>

  </div>
</div>
</body>
</html>
