<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Wellmeadows — Edit Patient</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --navy:#1B2D5B; --navy-dark:#111e3f; --navy-light:#2a4080;
    --sky:#5B9BD5; --sky-light:#A8CBF0; --sky-pale:#D6EAFA;
    --white:#FFFFFF; --off-white:#F4F8FC; --muted:#6B7E9F;
    --border:#C8D9EE; --text:#1a2640; --sidebar-w:210px;
    --error:#D94F4F; --success:#2E8B6A;
  }
  body { font-family:'DM Sans',sans-serif; background:var(--off-white); color:var(--text); display:flex; min-height:100vh; }
  .sidebar { width:var(--sidebar-w); background:var(--navy); display:flex; flex-direction:column; position:fixed; top:0; left:0; bottom:0; z-index:100; }
  .sidebar-logo { padding:22px 20px 18px; border-bottom:1px solid rgba(255,255,255,0.08); display:flex; align-items:center; gap:10px; }
  .logo-icon-sm { width:34px; height:34px; background:var(--sky); border-radius:8px; display:flex; align-items:center; justify-content:center; }
  .logo-icon-sm svg { width:18px; height:18px; fill:white; }
  .logo-text { font-family:'Playfair Display',serif; font-size:13px; color:white; line-height:1.2; }
  .logo-text span { display:block; font-family:'DM Sans',sans-serif; font-size:9px; color:var(--sky-light); letter-spacing:1px; text-transform:uppercase; }
  .nav-section { padding:16px 12px 8px; font-size:9px; letter-spacing:1.5px; text-transform:uppercase; color:rgba(255,255,255,0.3); font-weight:500; }
  .nav-item { display:flex; align-items:center; gap:10px; padding:10px 16px; margin:1px 8px; border-radius:8px; color:rgba(255,255,255,0.55); font-size:13px; transition:all 0.15s; text-decoration:none; }
  .nav-item:hover { background:rgba(255,255,255,0.08); color:white; }
  .nav-item.active { background:rgba(91,155,213,0.25); color:white; font-weight:500; }
  .nav-item svg { width:16px; height:16px; flex-shrink:0; }
  .sidebar-footer { margin-top:auto; padding:16px 12px; border-top:1px solid rgba(255,255,255,0.08); }
  .user-card { display:flex; align-items:center; gap:10px; padding:10px 12px; }
  .avatar { width:32px; height:32px; border-radius:50%; background:var(--sky); display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:600; color:white; }
  .user-name { font-size:12px; font-weight:500; color:white; }
  .user-role { font-size:10px; color:var(--sky-light); }
  .sign-out-btn { width:100%; margin-top:6px; padding:8px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); border-radius:7px; color:rgba(255,255,255,0.5); font-family:'DM Sans',sans-serif; font-size:12px; cursor:pointer; }
  .sign-out-btn:hover { background:rgba(255,255,255,0.12); color:white; }

  .main { margin-left:var(--sidebar-w); flex:1; display:flex; flex-direction:column; }
  .topbar { background:white; border-bottom:1px solid var(--border); padding:0 28px; height:58px; display:flex; align-items:center; justify-content:space-between; }
  .topbar h2 { font-family:'Playfair Display',serif; font-size:20px; }
  .back-btn { display:flex; align-items:center; gap:6px; padding:8px 16px; border:1px solid var(--border); border-radius:8px; font-size:13px; color:var(--muted); text-decoration:none; }
  .back-btn:hover { background:var(--sky-pale); color:var(--navy); }

  .content { padding:28px; max-width:680px; }
  .form-card { background:white; border:1px solid var(--border); border-radius:12px; padding:28px; }
  .form-card-title { font-family:'Playfair Display',serif; font-size:18px; color:var(--navy); margin-bottom:6px; }
  .form-card-sub { font-size:13px; color:var(--muted); margin-bottom:24px; }
  .form-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
  .form-group { display:flex; flex-direction:column; gap:5px; }
  .form-group.full { grid-column:1/-1; }
  label { font-size:11px; font-weight:500; color:var(--muted); text-transform:uppercase; letter-spacing:0.5px; }
  input, select, textarea { padding:9px 12px; border:1px solid var(--border); border-radius:8px; font-family:'DM Sans',sans-serif; font-size:13px; color:var(--text); background:var(--off-white); outline:none; }
  input:focus, select:focus, textarea:focus { border-color:var(--sky); background:white; }
  .form-actions { display:flex; gap:10px; justify-content:flex-end; margin-top:24px; padding-top:20px; border-top:1px solid var(--border); }
  .btn-cancel { padding:9px 20px; border:1px solid var(--border); border-radius:8px; background:white; font-family:'DM Sans',sans-serif; font-size:13px; cursor:pointer; color:var(--muted); text-decoration:none; }
  .btn-submit { padding:9px 20px; border:none; border-radius:8px; background:var(--navy); font-family:'DM Sans',sans-serif; font-size:13px; cursor:pointer; color:white; font-weight:500; }
  .checkbox-row { display:flex; align-items:center; gap:8px; font-size:13px; margin-top:6px; }
  .checkbox-row input { width:16px; height:16px; padding:0; }
</style>
</head>
<body>
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon-sm"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg></div>
    <div class="logo-text">Wellmeadows<span>Hospital</span></div>
  </div>
  <div class="nav-section">Main Menu</div>
  <a class="nav-item active" href="{{ route('patients.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
    Patients
  </a>
  <a class="nav-item" href="{{ route('staff.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
    Staff & Depts
  </a>
  <a class="nav-item" href="{{ route('wards.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
    Wards
  </a>
  <a class="nav-item" href="{{ route('appointments.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
    Appointments
  </a>
  <a class="nav-item" href="{{ route('billing.index') }}">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
    Billing
  </a>
  <div class="sidebar-footer">
    <div class="user-card">
      <div class="avatar">{{ strtoupper(substr(auth()->user()->first_name, 0, 1)) }}</div>
      <div>
        <div class="user-name">{{ auth()->user()->first_name }}</div>
        <div class="user-role">{{ auth()->user()->role }}</div>
      </div>
    </div>
    <form method="POST" action="{{ route('logout') }}">
      @csrf
      <button type="submit" class="sign-out-btn">Sign out</button>
    </form>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <h2>Edit Patient</h2>
    <a href="{{ route('patients.index') }}" class="back-btn">← Back to Patients</a>
  </div>
  <div class="content">
    <div class="form-card">
      <div class="form-card-title">{{ $patient->full_name }}</div>
      <div class="form-card-sub">Patient No: {{ $patient->patient_number }}</div>

      <form method="POST" action="{{ route('patients.update', $patient) }}">
        @csrf @method('PUT')
        <div class="form-grid">
          <div class="form-group">
            <label>First Name *</label>
            <input type="text" name="first_name" value="{{ old('first_name', $patient->first_name) }}" required>
            @error('first_name')<small style="color:#D94F4F">{{ $message }}</small>@enderror
          </div>
          <div class="form-group">
            <label>Last Name *</label>
            <input type="text" name="last_name" value="{{ old('last_name', $patient->last_name) }}" required>
            @error('last_name')<small style="color:#D94F4F">{{ $message }}</small>@enderror
          </div>
          <div class="form-group">
            <label>Date of Birth *</label>
            <input type="date" name="date_of_birth" value="{{ old('date_of_birth', $patient->date_of_birth->format('Y-m-d')) }}" required>
            @error('date_of_birth')<small style="color:#D94F4F">{{ $message }}</small>@enderror
          </div>
          <div class="form-group">
            <label>Gender *</label>
            <select name="gender" required>
              <option value="Male"   {{ old('gender', $patient->gender) === 'Male'   ? 'selected' : '' }}>Male</option>
              <option value="Female" {{ old('gender', $patient->gender) === 'Female' ? 'selected' : '' }}>Female</option>
              <option value="Other"  {{ old('gender', $patient->gender) === 'Other'  ? 'selected' : '' }}>Other</option>
            </select>
          </div>
          <div class="form-group">
            <label>Contact Number</label>
            <input type="text" name="contact_number" value="{{ old('contact_number', $patient->contact_number) }}">
          </div>
          <div class="form-group">
            <label>Admission Status</label>
            <div class="checkbox-row">
              <input type="checkbox" name="is_admitted" value="1" {{ old('is_admitted', $patient->is_admitted) ? 'checked' : '' }}>
              <span>Currently admitted</span>
            </div>
          </div>
          <div class="form-group full">
            <label>Address</label>
            <textarea name="address" rows="2">{{ old('address', $patient->address) }}</textarea>
          </div>
        </div>
        <div class="form-actions">
          <a href="{{ route('patients.index') }}" class="btn-cancel">Cancel</a>
          <button type="submit" class="btn-submit">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>
